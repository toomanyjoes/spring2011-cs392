//  jGABL - The Java Graph Algorithm Base Library
//  Copyright (C) 2000-2006  Alexander Schwartz
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
//  $ID: $
//  $Revision: 107 $

package net.sf.jgabl2.core.data.pq.impl;

import java.util.AbstractQueue;
import java.util.Comparator;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.jgabl2.core.data.pq.IMeltablePriorityQueue;
import net.sf.jgabl2.core.data.pq.IMutablePriorityQueue;
import net.sf.jgabl2.core.data.pq.IPriorityQueue;
import net.sf.jgabl2.core.util.check.CheckPolicy;
import net.sf.jgabl2.core.util.check.CheckPolicyManager;
import net.sf.jgabl2.core.util.check.InvariantType;
import net.sf.jgabl2.core.util.check.InvariantViolatedException;


/**
 * A fast alternative to <em>Fibonacci heaps</em>. A pairing heap is easier
 * to implement and much faster in practice than a Fibonacci heap. However, the
 * asymptotic complexity of some most operations is not known exactly.
 *
 * <p> <strong>Note that this implementation is not synchronized.</strong>
 *
 * @param <E>
 *
 * @author Alexander Schwartz
 *
 * @see "L. Fredman, R. Sedgewick, D. Sleator and R. Tarjan, <em>The Pairing Heap: A New Form of Self-Adjusting Heap</em>, Algorithmica, 1986(1), pages 111-129."
 */
public class PairingHeap<E>
        extends AbstractQueue<E>
        implements IMutablePriorityQueue<E>, IMeltablePriorityQueue<E> {

    // ~ Static variables/initializers
    // ==========================================

    /** The logger of this class. */
    private static final Logger LOG
        = Logger.getLogger(PairingHeap.class.getName());

    /** The check policy of this class. */
    private static CheckPolicy checkPolicy
        = CheckPolicyManager.getCheckPolicy(PairingHeap.class);

    // ~ Instance variables
    // =====================================================

    /**
     * The comparator, or null if priority queue uses elements' natural
     * ordering.
     */
    private Comparator<? super E> comparator = null;

    /**
     * The root of the enclosed tree, or <code>null</code>
     * if this collections is empty.
     */
    private TreeItem<E> root = null;

    /** The number of stored elements. */
    private int size = 0;


    // ~ Constructors
    // ===========================================================
    
    /**
     * Creates an instance using the default comparator.

     * @complexity constant-time
     */
    public PairingHeap() {
    	// nothing to do
    }
    
    /**
     * Creates an empty pairing heap that orders its elements according to the
     * specified comparator.
     *
     * @param comparator
     *            the comparator used to order this priority queue. If
     *            <tt>null</tt> then the order depends on the elements'
     *            natural ordering.
     * @complexity constant-time
     */
    public PairingHeap(Comparator<? super E> comparator) {
        this.comparator = comparator;
    }

    // ~ Methods
    // ================================================================

    /** {@inheritDoc} */
    public Comparator<? super E> comparator() {
        return comparator;
    }

    /** {@inheritDoc} */
    public int size() {
        return this.size;
    }


    /**
     * {@inheritDoc}
     *
     * @complexity constant-time (proved)
     */
    public final boolean isEmpty() {
        return (size == 0);
    }

    /**
     * {@inheritDoc}
     *
     * @complexity constant-time
     */
    public E peek() {
        if (isEmpty()) {
            return null;
        }
        return this.root.data;
    }

    //~ =========================================================
    // Modify: Inserting

    /**
     * {@inheritDoc}
     *
     * Returns <code>true</code>.
     */
    public boolean offer(E o) {

        insert(o);
        return true;
    }

    /**
     * {@inheritDoc}
     *
     * @complexity constant-time
     */
    public PositionHandle insert(E obj) {
    	
    	if (LOG.isLoggable(Level.FINER)) {
	        LOG.log(Level.FINER, 
	        		"Inserting '"  //$NON-NLS-1$
	        		+ obj 
	        		+ "' (current size is "  //$NON-NLS-1$
	        		+ size() 
	        		+ ")"); //$NON-NLS-1$
    	}

        final TreeItem item = new TreeItem(obj);
        setRoot(link(this.root, item));
        ++this.size;

        if (checkPolicy.checkInvariant(InvariantType.EXPENSIVE_INVARIANT)) {
            checkInvariant();
        }

        return new OwnPosHandle(item);
    }

    //~ =========================================================
    // Modify: Removing
    /**
     * {@inheritDoc}
     * @complexity amortized logarithmic-time (conjectured)
     */
    public E poll() {
        if (isEmpty()) {
            return null;
        }
        --size;

        E data = this.root.data;
        TreeItem child = this.root.child;

        if (child == null) {
            setRoot(null);

            checkInvariant();
            return data;
        }

        // parse one
        pairChildren(this.root);

        // parse two
        setRoot(linkChildren(root));

        checkInvariant();
        return data;
    }

    /**
     * {@inheritDoc}
     * @complexity amortized logarithmic-time (conjectured)
     */
    public void remove(IPriorityQueue.PositionHandle it) {
        if (it == null) {
            throw new IllegalArgumentException();
        }
        TreeItem<E> item = ((OwnPosHandle) it).item;
        assert(item != null);
        removeTreeItem(item);
    }

    // ~ =================================================
    // Modify: Change key

    /**
     * {@inheritDoc}
     * @complexity amortized constant-time (conjectured)
     */
    public void decreaseKey(PositionHandle it) {
        TreeItem item = ((OwnPosHandle) it).item;

        if (item == this.root) {
            return;
        }

        item.cutFromParent();
        setRoot(link(this.root, item));

        checkInvariant();
    }

    // ~ =================================================
    // Modify: melt


    /**
     * {@inheritDoc}
     *
     * @complexity constant-time
     */
    public void melt(IMeltablePriorityQueue<E> queue) {
        if  (!(queue instanceof IMeltablePriorityQueue)) {
            throw new IllegalArgumentException();
        }

        if (this.equals(queue)) {
            throw new IllegalArgumentException();
        }

        final PairingHeap P = (PairingHeap) queue;

        this.size += P.size;
        setRoot(link(this.root, P.root));
        P.root = null;
        P.size = 0;

        this.checkInvariant();
        P.checkInvariant();
    }

    // ~ =================================================

    private void removeTreeItem(TreeItem<E> item) {
        if (item == this.root) {
            poll();

            return;
        }
        item.cutFromParent();
        final PairingHeap P = new PairingHeap(this.comparator);
        P.size = 1; // may be WRONG!!!
        P.root = item;
        P.poll();
        melt(P);
    }

    private final TreeItem linkChildren(TreeItem parent) {
        TreeItem child = parent.child;
        TreeItem myroot = child;

        if (child == null) {
            return myroot;
        }

        child = child.sibling;
        myroot.sibling = null;

        while (child != null) {
            TreeItem next = child.sibling;

            child.sibling = null;
            myroot = link(myroot, child);
            child = next;
        }

        return myroot;
    }

    private final void pairChildren(TreeItem parent) {
        final TreeItem firstChild = parent.child;

        if (firstChild == null) {
            return;
        }

        parent.child = null;

        TreeItem next = firstChild;

        do {
            TreeItem child1 = next;
            TreeItem child2 = next.sibling;

            if (child2 == null) {
                parent.addChild(child1);

                return;
            }

            next = child2.sibling;

            child1.sibling = null;
            child2.sibling = null;

            parent.addChild(link(child1, child2));
        } while (next != null);
    }


    private TreeItem link(TreeItem<E> a, TreeItem<E> b) {
        if (a == null) {
            return b;
        }

        if (b == null) {
            return a;
        }

        if (compare(a.data, b.data) < 0) {
            a.addChild(b);
            return a;
        }

        b.addChild(a);
        return b;
    }

    private void setRoot(TreeItem<E> root) {
        this.root = root;

        if (root != null) {
            root.sibling = root.parent = null;
        }
    }

    private int compare(E a, E b) {
        if (this.comparator != null) {
            return comparator.compare(a, b);
        }

        if (!(a instanceof Comparable)) {
            throw new IllegalArgumentException(
                "No comparator given and the element type is not comparable."); //$NON-NLS-1$
        }

        final Comparable<E> comp = (Comparable<E>) a;
        return comp.compareTo(b);
    }


    /**
     * Checks the representation invariant.
     */
    protected void checkInvariant() {
        if (checkPolicy.checkInvariant(InvariantType.CHEAP_INVARIANT)) {
            checkSizeAndRoot();
        }

        if (!checkPolicy.checkInvariant(
                InvariantType.EXPENSIVE_INVARIANT)) {
            return;
        }

        int numberOfChilds = checkNode(this.root, null, ""); //$NON-NLS-1$
        if (numberOfChilds != this.size) {
            throw new InvariantViolatedException(
                            "Size is " + this.size //$NON-NLS-1$
                            + ", but the actual number of tree nodes is " //$NON-NLS-1$
                            + numberOfChilds);
        }
    }

    private void checkSizeAndRoot() {
        if (this.size < 0) {
            throw new InvariantViolatedException(
                            "Size is negative: " + this.size); //$NON-NLS-1$
        }
        boolean flagRootNull = (this.root == null);
        if (flagRootNull != (size == 0)) {
            throw new InvariantViolatedException(
                            "Size is " + this.size //$NON-NLS-1$
                            + " but root if " + this.root); //$NON-NLS-1$
        }
    }

    private final int checkNode(TreeItem item, TreeItem parent, String indent) {
        if (item == null) {
            return 0;
        }

        LOG.log(Level.FINER, indent + "CheckNode: node " + item + " has parent "
                + item.parent);

        if (item.parent != parent) {
            throw new InvariantViolatedException("node '" + item
                    + "' has wrong parent (" + item.parent + " instead of "
                    + parent + ")");
        }

        if (item == parent) {
            throw new InvariantViolatedException("node '" + item
                    + "' is its own parent.");
        }

        int numberOfChildsA = checkNode(item.sibling, parent, indent);
        int numberOfChildsB = checkNode(item.child, item, indent + "  ");

        return numberOfChildsA + numberOfChildsB + 1;
    }


    /** {@inheritDoc} */
    public Iterator<E> iterator() {
        throw new UnsupportedOperationException();
    }


    class OwnPosHandle<E> implements PositionHandle {
        // ~ Instance variables
        // =================================================

        TreeItem<E> item;

        // ~ Constructors
        // =======================================================

        public OwnPosHandle(TreeItem<E> item) {
            this.item = item;
        }

        public E getValue() {
            return item.data;
        }
    }

}

class TreeItem<E> {
    // ~ Instance variables
    // =================================================


    TreeItem parent = null;

    TreeItem child = null;

    TreeItem sibling = null;

    E data;

    // ~ Constructors
    // =======================================================

    TreeItem(E data) {
        this.data = data;
    }

    // ~ Methods
    // ============================================================

    void addChild(TreeItem<E> item) {
        item.sibling = child;
        item.parent = this;
        this.child = item;
    }

    void cutFromParent() {
        if (parent == null) {
            return;
        }

        if (parent.child == this) {
            parent.child = this.sibling;
        } else {
            TreeItem<E> sister = parent.child;

            while (sister.sibling != this) {
                sister = sister.sibling;
            }

            sister.sibling = this.sibling;
        }

        sibling = null;
        parent = null;
    }

    public String toString() {
        return "" + data;
    }

}
