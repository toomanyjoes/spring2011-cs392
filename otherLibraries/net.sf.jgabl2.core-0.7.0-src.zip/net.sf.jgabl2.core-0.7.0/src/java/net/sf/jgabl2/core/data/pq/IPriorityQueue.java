//  jGABL - The Java Graph Algorithm Base Library
//  Copyright (C) 2000-2006  Alexander Schwartz
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
//  $ID: $
//  $Revision: 102 $

package net.sf.jgabl2.core.data.pq;

import java.util.Comparator;
import java.util.NoSuchElementException;
import java.util.Queue;

/**
 * A priority queue of ordered objects. Stores a <code>Comparator</code> in
 * order to compare the stored <code>Object</code>s. <b>Warning: </b> You may
 * not change the order of the stored objects after inserting them in queue.
 *
 * @todo Add tests
 */
public interface IPriorityQueue<E> extends Queue<E> {

    //~ Methods ================================================================

	/**
     * Returns the comparator used to order this collection, or <tt>null</tt>
     * if this collection is sorted according to its elements natural ordering
     * (using <tt>Comparable</tt>).
     *
     * @return the comparator used to order this collection, or <tt>null</tt>
     * if this collection is sorted according to its elements natural ordering.
     */
	public Comparator<? super E> comparator();


    /**
     * Adds a given object. It is allowed to store objects which are equal, or
     * to store the same object several times. <br>
     * <b>Warning: </b> You may not change the order of the stored objects
     * after inserting them in queue.
     *
     * @param obj the item to be inserted
     *
     * @return an iterator which refers to the inserted object (which does not
     *         necessarily iterates the stored elements)
     */
    public PositionHandle<E> insert(E obj);

    //~ Interfaces =============================================================

    public interface PositionHandle<E> {
		E getValue();
    }
}
