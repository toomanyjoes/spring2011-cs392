//  jGABL - The Java Graph Algorithm Base Library
//  Copyright (C) 2000-2006  Alexander Schwartz
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
//  $ID: $
//  $Revision: 45 $

package net.sf.jgabl2.core.data.pq;

/**
 * A priority queue which provides <code>decreaseKey</code> and
 * <code>remove</code>.
 */
public interface IMutablePriorityQueue<E> extends IPriorityQueue<E> {
    //~ Methods ================================================================

    /**
     * Adjusts the position of a stored element which the iterator refers to.
     * Assumes that the 'key' of the object had been decreased. Write
     * <pre>
     * Object data = it.getObject();
     * Q.remove(it);
     * it = Q.add(data);
     * </pre>
     * in order to adjust the position of a stored element which the iterator
     * <code>it</code> refers to, in the case that the 'key' of the object had
     * been increased.
     *
     * @param item DOCUMENT ME!
     *
     * @precondition iterator is valid and refers to a valid element of this
     *               queue
     */
    public void decreaseKey(PositionHandle item);

    /**
     * Removes the element which the iterator refers to. <br>
     * <b>Attention: </b> The used iterator object has to be returned by
     * <code>add</code>!
     *
     * @param item DOCUMENT ME!
     *
     * @precondition iterator is valid and refers to a valid element of this
     *               queue
     */
    public void remove (PositionHandle item);
}
