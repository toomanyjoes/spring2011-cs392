//  jGABL - The Java Graph Algorithm Base Library
//  Copyright (C) 2000-2005  Alexander Schwartz
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


package net.sf.jgabl2.core.util.check;

/**
 * Represents the "expensiveness" of an invariant.

 * @author Alexander Schwarz
 */
public enum InvariantType {
	
	/**
	 * To be used for invariants which 
	 * can be checked without spoiling the symprotic running time.
	 */
	CHEAP_INVARIANT, 
	
	/**
	 * To be used for invariants which are expensive when checked.
	 */
	EXPENSIVE_INVARIANT
}
