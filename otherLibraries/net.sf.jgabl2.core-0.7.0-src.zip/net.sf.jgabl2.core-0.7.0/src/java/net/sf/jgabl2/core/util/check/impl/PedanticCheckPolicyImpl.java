//  jGABL - The Java Graph Algorithm Base Library
//  Copyright (C) 2000-2005  Alexander Schwartz
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
//  $ID: $
//  $Revision: 107 $

package net.sf.jgabl2.core.util.check.impl;

import net.sf.jgabl2.core.util.check.CheckPolicy;
import net.sf.jgabl2.core.util.check.InvariantType;

/**
 * Pendantic checkPolicy: Checks all, but not the invariant at the begin of a
 * method.
 */
public class PedanticCheckPolicyImpl implements CheckPolicy {
    //~ Methods ================================================================

    /**
     * Returns <code>true</code>.
     *
     * @return <code>true</code>
     */
    public boolean checkAssumption() {
        return true;
    }

    /**
     * Returns <code>true</code>.
     *
     * @return <code>true</code>
     */
    public boolean checkPrecond() {
        return true;
    }

    /**
     * Returns <code>true</code>.
     *
     * @return <code>true</code>
     */
    public boolean checkPostCond() {
        return true;
    }

    /**
     * Returns <code>true</code>.
     *
     * @return <code>true</code>
     */
    public boolean checkLoopInvariant() {
        return true;
    }

    /**
     * Returns <code>true</code>.
     *
     * @return <code>true</code>
     */
    public boolean checkInvariant(InvariantType type) {
        return true;
    }
}
