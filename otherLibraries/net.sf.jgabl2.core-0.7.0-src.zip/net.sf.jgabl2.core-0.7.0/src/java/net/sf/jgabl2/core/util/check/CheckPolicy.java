//  jGABL - The Java Graph Algorithm Base Library
//  Copyright (C) 2000-2005  Alexander Schwartz
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
//  $ID: $
//  $Revision: 13 $

package net.sf.jgabl2.core.util.check;

/**
 * Traits for checking of invariants and conditions. To be used by non-trivial
 * data structures and algorithms.
 *
 * <p>
 * <b>Sample: </b>
 * </p>
 *
 * <p>
 * <pre>
 *
 *   public class CheckingStack {
 *       CheckPolicy  checkPolicy;
 *       Object[] stack;
 *       int      last = -1;
 *
 *       &lt;b&gt;protected void checkInvariant() throws InvariantViolatedException {
 *
 *       }&lt;/b&gt;
 *
 *       public CheckingStack ( int capacity, CheckPolicy checkPolicy ) {
 *           this.checkPolicy = checkPolicy;
 *           stack = new Object[capacity];
 *
 *            if (checkPolicy.checkInvariant())
 *                checkInvariant();
 *       }
 *
 *
 *       public void pop() {&lt;b&gt;
 *            if (checkPolicy.checkPostcond() &amp;&amp; isEmpty())
 *               throw new PrecondFailedException(&quot;!isEmpty()&quot;);&lt;/b&gt;
 *
 *           --last;
 *       }
 *
 *       // unchecked version
 *       public Object _top() {
 *            return stack[last];
 *       }
 *
 *       public Object top() {
 *            &lt;b&gt;if (checkPolicy.checkPostcond() &amp;&amp; isEmpty())
 *               throw new PrecondFailedException(&quot;!isEmpty()&quot;);&lt;/b&gt;
 *
 *            return stack[last];
 *       }
 *
 *       public void push ( Object value ) {
 *           &lt;b&gt;if (checkPolicy.checkPrecond())
 *            if (!(last &lt; stack.length-1))
 *            throw new PrecondFailedException(&quot;last &lt; stack.length-1&quot;);
 *
 *            if (checkPolicy.checkInvariantPedantic())
 *                checkInvariant();&lt;/b&gt;
 *
 *           stack[++last] = value;
 *
 *            &lt;b&gt;if (checkPolicy.checkInvariant())
 *                checkInvariant();
 *
 *            if (checkPolicy.checkPostcond()) {
 *                if (isEmpty())
 *                    throw new PostcondFailedException(&quot;!isEmpty()&quot;);
 *                if (_top() != value) // using uncheck version !
 *                    throw new PostcondFailedException(&quot;top() == value&quot;);
 *            }&lt;/b&gt;
 *
 *       }
 *
 *
 *
 *    }
 *
 * </pre>
 * </p>
 */
public interface CheckPolicy {
    //~ Methods ================================================================

    public boolean checkPrecond ();

    public boolean checkPostCond ();

    public boolean checkAssumption ();

    public boolean checkLoopInvariant ();

    public boolean checkInvariant (InvariantType invariantType);

}


