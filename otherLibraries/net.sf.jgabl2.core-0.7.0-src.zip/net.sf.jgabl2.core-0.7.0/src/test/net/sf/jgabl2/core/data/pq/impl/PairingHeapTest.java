//  jGABL - The Java Graph Algorithm Base Library
//  Copyright (C) 2000-2005  Alexander Schwartz
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
//  $ID: $
//  $Revision: 13 $

package net.sf.jgabl2.core.data.pq.impl;

import java.util.NoSuchElementException;

import junit.framework.TestCase;

public class PairingHeapTest extends TestCase {

	PairingHeap<Float> pq;

	protected void setUp() throws Exception {
		super.setUp();

		this.pq = new PairingHeap();
	}

	public void testEmpty() {
		assertTrue(pq.isEmpty());
		assertEquals(0,pq.size());

		assertEquals(null, pq.peek());
		assertEquals(null, pq.poll());

		try {
			pq.remove();
		} catch(NoSuchElementException e) {

		} catch(Throwable e) {
			fail("");
		}

	}
}
