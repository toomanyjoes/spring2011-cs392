/**
	* @author Robert Cohen (rfc)
	* @version JDSL 2
	*/
interface CountDownTimerListener {
  public void timerTicked(CountDownTimerEvent e);
}     
